package com.cantika.jalores.helper;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}

